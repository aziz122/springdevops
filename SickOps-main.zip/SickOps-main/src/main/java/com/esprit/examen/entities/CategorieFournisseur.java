package com.esprit.examen.entities;

public enum CategorieFournisseur {
ORDINAIRE,CONVENTIONNE
}
